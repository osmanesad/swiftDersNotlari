import UIKit

// ? !

var myName : String? // İsim yerine ? işareti korsam - Bunu girebilirde girmeyebilirde kişi manası > var myName : String?


myName?.lowercased() // ! işareti koyarsam - Vallaha girecek olmazsa olmaz abicim > myName!.lowercased() -> ama girmezse patladın

// Şimdi gelelim gerçekten vallahalık duruma

var myAge = "Hayıır" // buranın içerisine String değer girersem aşağıda patlama durumları var

//  var sonuc = Int(myAge)! + 20 // Şimdi burada kullanıcının gerçekten bir Int değeri girdiğine eminsem ! işaretini sona eklemem lazım. Ama kullanıcı Int bir değer girmezse yine patlarım bu yüzden ?? işareti gerekebilir.

var sonuc2 = (Int(myAge) ?? 0) + 40 // İşte burada da diyorum ki eğer vatandaş Int değeri girmezse sonucu patlatmada 0 yerine koyacağım değeri yazdırda atlatalım


// if ile kontrol etme

if let sonuc3 = Int(myAge){ // Burada da sözlü uyarı verdirdik. if let -> eğerki olursa yapabilrsen hani
    
    print(sonuc3 + 50)
    
}else {
    
    print("Kardeş sen hayırdır, rakam gir rakam!")
}
