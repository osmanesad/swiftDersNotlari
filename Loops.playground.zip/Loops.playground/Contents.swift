import UIKit

var myNumber = 1

myNumber += 1

myNumber = myNumber + 1 //Boşluklara yazım  kurallarına dikkat !

myNumber -= 1


var number = 0

// While Loop

while number <= 10 {
    print(number)
    
    number += 1
}

var karakterAlive = true

while karakterAlive == true {
    print("karakter canlı")
    karakterAlive = false
}


3 > 6

2 < 7

5 == 5

5 <= 6

4 != 5

// for - loop

var meyvelerim = ["elma","cilek","armut","kivi"]

for sepetim in meyvelerim {
    
    print(sepetim)
}

var myNumbers = [20,30,40,50]


for bolme in myNumbers {
    print(bolme / 5)
    
}

for yeniNumara in 1 ... 5 {
    print(yeniNumara + 3)
}


// odev - soru

var fibonacciArray = [1,1,2,3,5,8,13]

for number in fibonacciArray {
    
    let myNumberx = number * 5
    print(myNumberx)
}
