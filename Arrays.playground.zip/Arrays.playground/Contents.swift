import UIKit

// Arrays - > Birden fazla değişkeni aynı anda tutmak.

var myFavFilms = ["Yüzüklerin Efendisi","Matrix","Inception"]

print(myFavFilms)

var myFavs = ["Yüzüklerin Efendisi","Matrix","Inception",6,true] as [Any]

//as -> casting
// Any -> any object

//index -> 0=1 1=2 gibi
myFavs[0]
myFavs[1]

myFavs[3].self

//myFavs[0].uppercased() yapamıyorum.

var newDizi = ["araba","MOTOR","benzin","pompacı"]

newDizi[0].uppercased()
newDizi[1].lowercased()
newDizi[2].append("lik")

print(newDizi)

newDizi.count

newDizi[newDizi.count - 2]

newDizi.last

newDizi.sort()

// Set

// Unordered collection, unique elements
var mySet : Set = [1,2,3,4,5,6,3,4,5,7]

var myStirngSet : Set = ["ali","veli","ali","osman"]

var myTestSetList = [1,2,3,4,5,6,7]

var myTestSet = Set(myTestSetList)


print(myTestSetList)
print(myTestSet)



var yeniSet1 : Set = [1,2,3]
var yeniSet2 : Set = [3,4,5]

var yeniSet3 = yeniSet1.union(yeniSet2)

print(yeniSet3)


// Dictionary -> Sözlük

// key-value pairing


var myFavGamesCharacter = ["Witcher" : "Geralt","Warcraft" : "Arthas","Assasins Creed" : "Ezio","Metro" : "Artyom"]

myFavGamesCharacter["Witcher"]
myFavGamesCharacter["Metro"]

myFavGamesCharacter["Assasins Creed"] = "Altair"

myFavGamesCharacter["Assasins Creed"]

myFavGamesCharacter["Call of Duty"] = "Ghost"

print(myFavGamesCharacter)

var newDictionary = ["Ayşe" : 90, "Ali" : 87, "Mehmet" : 66]

newDictionary["Ali"]

print(newDictionary)
