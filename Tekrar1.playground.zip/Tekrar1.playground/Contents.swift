import UIKit

var name = "osman"

let userName = "esad"

print(name + " " + userName)

name.uppercased()
userName.uppercased()

print(name + " " + userName)

var myNumber = 5 * 2

name = "koray"

// Program okuma sırası yukarıdan aşağıya doğru.
// Yani kafama göre yukariya ayrı aşağıya ayrı birşeyler yazamam. Tanımaz.

//mutable -> sonradan değişebilir örneğin var gibi
//immutable -> sonradan değişmeyen örneğin let gibi

let myAge = 30

//myAge = 20 // Olamaz.

let numberD = 51.5 //double

let numberI = 34 // Integer

let myInteger : Int // Önceden türünü belirtiyorum.

myInteger = 30

let kelime = "Ekle"

//kelime.append("dim") -> Eklemdim sonucunu vermez çünkü let

var kelime2 = "Ekle"

kelime2.append("dim")

print(kelime2)


let userId1 = 50.0

let userId2 = 4.0

userId1 / userId2 // sonuc double yani 12.5



var sonuc = userId1 + userId2

print(sonuc)


//boolean

var myBoolean = false

myBoolean = true

// var olan bir sınıf Büyük harf ile başlar

var myString : String = "Ali"

var myNewNumber: String = "5"

// myNewNumber * 4 // olamaz

let newNumberD : Int = Int(34.5) // yazabilirm

let numberDouble : Double = 23.5

let stringNumber : String = String(20)
