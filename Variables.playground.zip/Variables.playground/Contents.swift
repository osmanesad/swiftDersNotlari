import UIKit

// Variables ve Constants


var userName = "Osman"
var userSurname = "Esad"

userName = "Camel"
print(userName)

userName="Turk"
print(userName)


// var bir değişken ve en son ne yazdıysak değer onu alıyor.

let userAge = 27.0

// userAge = 30 // Bunu yapamam !

print(userAge)

let pi = 3.14

// userAge * pi // Bunuda yapamıyorum çünkü türleri farklı biri Int diğeri Double

// userAge değerini 27.0 yaparsak

userAge * pi


//String

userName.append("H") // Sonuna ekle

userName.lowercased()

//Numbers

let Age=47 //Integer

let myNumber=5 // Integer

// double

Age / myNumber // 9.4 civarı olması lazım ama tam sayı veriyor.

let userAgeD=47.0 //double
let myNumberD=5.0 //double

userAgeD / myNumberD // sonuc küsüratlı 9.4

//boolean -> true yada false değeri alır

var myBoolean = false
myBoolean = true






