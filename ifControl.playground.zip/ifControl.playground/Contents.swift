import UIKit

// if -> Eğer

var myAge = 45

if myAge < 30 {
    
    print("Yaşın 30'dan küçük")
    
} else if myAge > 30 && myAge < 50 {
    
    print("Yaşın 30 ile 50 arasında: ", myAge)
    
} else {
    print("40 +")
}

// && -> ve operatörü
// || -> or veya ( option tuşuna basılı tutup tire tuşuna bas)

3 < 5 && 9 < 8 // her iki tarafında kontrolü

3 < 5 || 8 < 7 // sol tarafın doğru olması yetti


var name = "Osman"

if name == "osman" {
    print("Adını doğru girdin")
} else {
    print("Adını doğru girmedin, doğrusu:", name, "olması lazım.")
}


