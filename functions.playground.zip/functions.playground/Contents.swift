import UIKit


// function -> Fonksiyonlar

func myFunction(){
    print("Test Fonksiyon")
}

myFunction()

// input - outpu - return

func toplamaFonksiyonu(x: Int, y: Int){
    
    print(x + y)
}

toplamaFonksiyonu(x: 3, y: 4)

//return

func dondurmeliFonk(x: Int, y: Int) -> Int{
    return x + y
}

let sonucFonk = dondurmeliFonk(x: 6, y: 5)

print(sonucFonk)


func boolFonk(a: Int, b: Int) -> Bool  { //String
    
    if a > b {
        return true // "Büyük"
    }else {
        return false // "Küçük"
    }
}

boolFonk(a: 3, b: 7)
