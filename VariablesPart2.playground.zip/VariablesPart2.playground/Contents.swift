import UIKit

var myString: String // Sınıf adı

var benimMetnim: String = "Metinsel Değerler"

let myNumber: Int=5

let otherNumber: Double = 50.5


let stringNumber: String = String(20)

//define

let myVariables : String

//initialization

myVariables = "osman"

// myVariables.uppercased() // bunu öncesinde yazamam. önce değeri doldurmam lazım.

print(myVariables) // Küçük yazar

let myUpperVariables = myVariables.uppercased()

print(myUpperVariables) //Büyük yazar
print(myVariables) // Küçük yazar

